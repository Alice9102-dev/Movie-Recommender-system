import pickle
import streamlit as st
import requests

# === CONFIG ===
st.set_page_config(page_title="Movie Recommender", layout="wide")
API_KEY = "3460d26467478ab1c24d5c8c1bc78d34"

# === UTILS ===
def fetch_poster(movie_id):
    try:
        url = f"https://api.themoviedb.org/3/movie/{movie_id}?api_key={API_KEY}&language=en-US"
        response = requests.get(url)
        data = response.json()
        poster_path = data.get('poster_path')
        if not poster_path:
            return "https://via.placeholder.com/300x450?text=No+Image"
        return f"https://image.tmdb.org/t/p/w500/{poster_path}"
    except Exception as e:
        print(f"Error fetching poster for movie ID {movie_id}: {e}")
        return "https://via.placeholder.com/300x450?text=Error"

def recommend(movie):
    index = movies[movies['title'] == movie].index[0]
    distances = sorted(list(enumerate(similarity[index])), reverse=True, key=lambda x: x[1])

    recommended_names = []
    recommended_posters = []

    for i in distances[1:6]:
        movie_id = movies.iloc[i[0]].movie_id
        recommended_names.append(movies.iloc[i[0]].title)
        recommended_posters.append(fetch_poster(movie_id))

    return recommended_names, recommended_posters

# === MAIN APP ===
st.title("🎬 Movie Recommender System")
st.markdown("##### Get movie recommendations based on your favorite films!")

# Load Data
movies = pickle.load(open('movie_list.pkl', 'rb'))
similarity = pickle.load(open('similarity.pkl', 'rb'))

movie_list = movies['title'].values
selected_movie = st.selectbox("🔍 Type or select a movie:", movie_list)

if st.button("🎥 Show Recommendations"):
    with st.spinner("Finding great picks for you..."):
        names, posters = recommend(selected_movie)

        # 5-column layout for movies
        cols = st.columns(5)
        for idx, col in enumerate(cols):
            with col:
                st.image(posters[idx], use_container_width=True)
                st.caption(names[idx])
